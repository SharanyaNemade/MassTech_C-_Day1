﻿using System;

class Test
{
    public static void displayStatic()
    {
        Console.WriteLine("This is a Static Method");
    }

    public void displayNonStatic()
    {
        Console.WriteLine("This is a Non Static Method");
    }

    public string getName(string name)
    {
        return name;
    }

    public double disAdd(int a, int b)
    {
        double c = a + b;
        return c;
    }
}
