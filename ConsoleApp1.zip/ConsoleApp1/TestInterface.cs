﻿using System;


interface TestInterface
{
    void disData();

    void RawData();
}