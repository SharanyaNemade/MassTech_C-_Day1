﻿using System;

class Program
{
    static void Main(String[] args)
    {
        Test.displayStatic();
        Test obj = new Test();
        obj.displayNonStatic();


        string s = obj.getName("John");
        Console.WriteLine(s);

        double x = obj.disAdd(3,4);
        Console.WriteLine(x);


        InterfaceImpl impl = new InterfaceImpl();
        impl.disData();
        impl.RawData();
    }
}