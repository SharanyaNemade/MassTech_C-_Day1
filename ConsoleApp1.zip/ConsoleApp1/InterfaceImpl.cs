﻿using System;

class InterfaceImpl : TestInterface
{
    public void disData()
    {
        Console.WriteLine("Method2 from Interface");
    }

    public void RawData()
    {
        Console.WriteLine("Method2 from Interface");
    }



}
